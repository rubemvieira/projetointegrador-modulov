--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5
-- Dumped by pg_dump version 10.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.pedido DROP CONSTRAINT pedido_pessoa_fkey;
ALTER TABLE ONLY public.pedido DROP CONSTRAINT pedido_forma_pgto_fkey;
ALTER TABLE ONLY public.itenspedido DROP CONSTRAINT itenspedido_servico_fkey;
ALTER TABLE ONLY public.itenspedido DROP CONSTRAINT itenspedido_produto_fkey;
ALTER TABLE ONLY public.itenspedido DROP CONSTRAINT itenspedido_pessoa_fkey;
ALTER TABLE ONLY public.fone DROP CONSTRAINT fone_pessoa_fkey;
ALTER TABLE ONLY public.servico DROP CONSTRAINT servico_pkey;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_pkey;
ALTER TABLE ONLY public.pessoa DROP CONSTRAINT pessoa_pkey;
ALTER TABLE ONLY public.pedido DROP CONSTRAINT pedido_pkey;
ALTER TABLE ONLY public.itenspedido DROP CONSTRAINT itenspedido_pkey;
ALTER TABLE ONLY public.forma_pgto DROP CONSTRAINT forma_pgto_pkey;
ALTER TABLE ONLY public.fone DROP CONSTRAINT fone_pkey;
ALTER TABLE public.produto ALTER COLUMN pro_id DROP DEFAULT;
DROP TABLE public.servico;
DROP SEQUENCE public.servico_serv_id_seq;
DROP SEQUENCE public.produto_pro_id_seq;
DROP TABLE public.produto;
DROP TABLE public.pessoa;
DROP SEQUENCE public.pessoa_pessoa_id_seq;
DROP TABLE public.pedido;
DROP SEQUENCE public.pedido_pedido_id_seq;
DROP TABLE public.itenspedido;
DROP SEQUENCE public.itenspedido_itenspedido_id_seq;
DROP TABLE public.forma_pgto;
DROP SEQUENCE public.forma_pgto_id_seq;
DROP TABLE public.fone;
DROP SEQUENCE public.fone_fone_id_seq;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: fone_fone_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fone_fone_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fone_fone_id_seq OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: fone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fone (
    fone_id integer DEFAULT nextval('public.fone_fone_id_seq'::regclass) NOT NULL,
    pessoa_id integer NOT NULL,
    numero character varying(100) NOT NULL,
    descricao character varying(100)
);


ALTER TABLE public.fone OWNER TO postgres;

--
-- Name: forma_pgto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.forma_pgto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forma_pgto_id_seq OWNER TO postgres;

--
-- Name: forma_pgto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forma_pgto (
    fpg_id integer DEFAULT nextval('public.forma_pgto_id_seq'::regclass) NOT NULL,
    fpg_descricao character varying(60),
    fpg_num_max_parc integer,
    fpg_num_padrao_parc integer,
    fpg_intervalo_dias integer,
    fpg_percentual_acres double precision
);


ALTER TABLE public.forma_pgto OWNER TO postgres;

--
-- Name: itenspedido_itenspedido_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.itenspedido_itenspedido_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.itenspedido_itenspedido_id_seq OWNER TO postgres;

--
-- Name: itenspedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.itenspedido (
    itenspedido_id integer DEFAULT nextval('public.itenspedido_itenspedido_id_seq'::regclass) NOT NULL,
    pedido_id integer NOT NULL,
    produto_id integer,
    servico_id integer,
    dataautorizacao date,
    qtde numeric(10,2),
    valorunit numeric(10,2),
    subtotal numeric(10,2)
);


ALTER TABLE public.itenspedido OWNER TO postgres;

--
-- Name: pedido_pedido_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_pedido_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_pedido_id_seq OWNER TO postgres;

--
-- Name: pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido (
    pedido_id integer DEFAULT nextval('public.pedido_pedido_id_seq'::regclass) NOT NULL,
    pessoa_id integer NOT NULL,
    fpg_id integer NOT NULL,
    dataemissao date,
    status character varying(100),
    dataautorizacao date,
    totalproduto numeric(10,2),
    totalservico numeric(10,2),
    totalgeral numeric(10,2),
    desconto numeric(10,2)
);


ALTER TABLE public.pedido OWNER TO postgres;

--
-- Name: pessoa_pessoa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pessoa_pessoa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pessoa_pessoa_id_seq OWNER TO postgres;

--
-- Name: pessoa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pessoa (
    pessoa_id integer DEFAULT nextval('public.pessoa_pessoa_id_seq'::regclass) NOT NULL,
    nome character varying(100) NOT NULL,
    cpf character varying(100),
    rg character varying(100),
    datanasc date,
    rua character varying(100),
    bairro character varying(100),
    cidade character varying(100),
    uf character varying(100),
    cep integer,
    email character varying(100),
    senha character varying(400),
    tipo character varying(100)
);


ALTER TABLE public.pessoa OWNER TO postgres;

--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produto (
    pro_id integer NOT NULL,
    pro_nome character varying(60),
    pro_preco double precision
);


ALTER TABLE public.produto OWNER TO postgres;

--
-- Name: produto_pro_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_pro_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_pro_id_seq OWNER TO postgres;

--
-- Name: produto_pro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_pro_id_seq OWNED BY public.produto.pro_id;


--
-- Name: servico_serv_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.servico_serv_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.servico_serv_id_seq OWNER TO postgres;

--
-- Name: servico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.servico (
    serv_id integer DEFAULT nextval('public.servico_serv_id_seq'::regclass) NOT NULL,
    serv_nome character varying(60),
    serv_descricao character varying(60),
    serv_und character varying(60),
    serv_valor double precision
);


ALTER TABLE public.servico OWNER TO postgres;

--
-- Name: produto pro_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto ALTER COLUMN pro_id SET DEFAULT nextval('public.produto_pro_id_seq'::regclass);


--
-- Data for Name: fone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fone (fone_id, pessoa_id, numero, descricao) FROM stdin;
\.
COPY public.fone (fone_id, pessoa_id, numero, descricao) FROM '$$PATH$$/2866.dat';

--
-- Data for Name: forma_pgto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forma_pgto (fpg_id, fpg_descricao, fpg_num_max_parc, fpg_num_padrao_parc, fpg_intervalo_dias, fpg_percentual_acres) FROM stdin;
\.
COPY public.forma_pgto (fpg_id, fpg_descricao, fpg_num_max_parc, fpg_num_padrao_parc, fpg_intervalo_dias, fpg_percentual_acres) FROM '$$PATH$$/2858.dat';

--
-- Data for Name: itenspedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.itenspedido (itenspedido_id, pedido_id, produto_id, servico_id, dataautorizacao, qtde, valorunit, subtotal) FROM stdin;
\.
COPY public.itenspedido (itenspedido_id, pedido_id, produto_id, servico_id, dataautorizacao, qtde, valorunit, subtotal) FROM '$$PATH$$/2868.dat';

--
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pedido (pedido_id, pessoa_id, fpg_id, dataemissao, status, dataautorizacao, totalproduto, totalservico, totalgeral, desconto) FROM stdin;
\.
COPY public.pedido (pedido_id, pessoa_id, fpg_id, dataemissao, status, dataautorizacao, totalproduto, totalservico, totalgeral, desconto) FROM '$$PATH$$/2867.dat';

--
-- Data for Name: pessoa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pessoa (pessoa_id, nome, cpf, rg, datanasc, rua, bairro, cidade, uf, cep, email, senha, tipo) FROM stdin;
\.
COPY public.pessoa (pessoa_id, nome, cpf, rg, datanasc, rua, bairro, cidade, uf, cep, email, senha, tipo) FROM '$$PATH$$/2862.dat';

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produto (pro_id, pro_nome, pro_preco) FROM stdin;
\.
COPY public.produto (pro_id, pro_nome, pro_preco) FROM '$$PATH$$/2856.dat';

--
-- Data for Name: servico; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.servico (serv_id, serv_nome, serv_descricao, serv_und, serv_valor) FROM stdin;
\.
COPY public.servico (serv_id, serv_nome, serv_descricao, serv_und, serv_valor) FROM '$$PATH$$/2857.dat';

--
-- Name: fone_fone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fone_fone_id_seq', 1, false);


--
-- Name: forma_pgto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.forma_pgto_id_seq', 2, true);


--
-- Name: itenspedido_itenspedido_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.itenspedido_itenspedido_id_seq', 7, true);


--
-- Name: pedido_pedido_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_pedido_id_seq', 12, true);


--
-- Name: pessoa_pessoa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pessoa_pessoa_id_seq', 3, true);


--
-- Name: produto_pro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_pro_id_seq', 5, true);


--
-- Name: servico_serv_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.servico_serv_id_seq', 2, true);


--
-- Name: fone fone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fone
    ADD CONSTRAINT fone_pkey PRIMARY KEY (fone_id);


--
-- Name: forma_pgto forma_pgto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forma_pgto
    ADD CONSTRAINT forma_pgto_pkey PRIMARY KEY (fpg_id);


--
-- Name: itenspedido itenspedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itenspedido
    ADD CONSTRAINT itenspedido_pkey PRIMARY KEY (itenspedido_id);


--
-- Name: pedido pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (pedido_id);


--
-- Name: pessoa pessoa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa
    ADD CONSTRAINT pessoa_pkey PRIMARY KEY (pessoa_id);


--
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (pro_id);


--
-- Name: servico servico_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servico
    ADD CONSTRAINT servico_pkey PRIMARY KEY (serv_id);


--
-- Name: fone fone_pessoa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fone
    ADD CONSTRAINT fone_pessoa_fkey FOREIGN KEY (pessoa_id) REFERENCES public.pessoa(pessoa_id);


--
-- Name: itenspedido itenspedido_pessoa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itenspedido
    ADD CONSTRAINT itenspedido_pessoa_fkey FOREIGN KEY (pedido_id) REFERENCES public.pedido(pedido_id);


--
-- Name: itenspedido itenspedido_produto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itenspedido
    ADD CONSTRAINT itenspedido_produto_fkey FOREIGN KEY (produto_id) REFERENCES public.produto(pro_id);


--
-- Name: itenspedido itenspedido_servico_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itenspedido
    ADD CONSTRAINT itenspedido_servico_fkey FOREIGN KEY (servico_id) REFERENCES public.servico(serv_id);


--
-- Name: pedido pedido_forma_pgto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_forma_pgto_fkey FOREIGN KEY (fpg_id) REFERENCES public.forma_pgto(fpg_id);


--
-- Name: pedido pedido_pessoa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_pessoa_fkey FOREIGN KEY (pessoa_id) REFERENCES public.pessoa(pessoa_id);


--
-- PostgreSQL database dump complete
--

